/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise14_part2;

/**
 * @author Johan van den Heuvel s47704528
 * @author Niels Korporaal s4768256
 */
public class Exercise14 {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /**
         * need to figure out a way to use small input buffer and 
         * reuse it
         */
        Primes p = new Primes();
        p.run();
    }
}